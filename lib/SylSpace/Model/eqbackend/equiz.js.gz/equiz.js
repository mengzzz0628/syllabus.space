    <script type="text/javascript" src="/static/jquery.filedrop.js"></script>
    <script type="text/javascript" src="/static/chosen.jquery.js"></script>



function validatenum(evt) {
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode( key );
    var regex = /[0-9]\-|\./;
    if( !regex.test(key) ) {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
}

function drawquiznavbar(this) {
    document.write("
	<!-- Navigation quiznavbar -->
          <nav>
            <table class=\"navbar\" style=\"background-color:#0076BA;width:100%\" border=\"1\">
              <tr>
                <td style=\"width:10px\"> <input type=\"button\" onclick=\"showQuestion(0,1)\" value=\"|&leq;&leq;\"> </td>
                <td style=\"width:10px\"> <input type=\"button\" onclick=\"showQuestion(-1,0)\" value=\"&leq;\"> </td>
                <td style=\"text-align:center\">
                  <select class='selectPage' onchange=\"displayPage(this.value)\">);
                    [- drawselectors() -]
                  </select>
                  <input type=\"checkbox\" class=\"singleFull\" onclick=\"displayAllInfo(this)\">
                  <span style=\"color:white\">View All Pages</span>
                </td>
                <td style=\"width:10px\"> <input type=\"button\" onclick=\"showQuestion(+1,0)\" value=\"&gt;\"> </td>
                <td style=\"width:10px\"> <input type=\"button\" onclick=\"showQuestion(0,100)\" value=\"&gt;&gt;|\"> </td>
              </tr>
            </table>
          </nav>
"); }

