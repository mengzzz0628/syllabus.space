#!/usr/bin/env perl
package SylSpace::Controller::instructorgradeenter;
use Mojolicious::Lite;

use SylSpace::Model::Model; ##  qw( );
use SylSpace::Model::Utils; ##  qw(subdomain);

################################################################

get '/instructor/gradeenter' => sub {
  my $c = shift;
  my $subdomain = standard( $c );
  sudo( $subdomain, $c->session->{uemail} );

  my @g= gradelist( $subdomain, $c->session->{uemail} );

  $c->stash( user=>$g[0], hw => $g[1], grades => $g[2], timestamp => $g[3] );
};

1;

################################################################

__DATA__

@@ instructorgradeenter.html.ep

%title '/instructor/gradeenter';
%layout 'instructor';

<main>

  <form class="form-horizontal" method="POST" action="/instructor/gradesave">

  <%
  sub entercell { return '<input size="6" type="text" value="'.($_[0]||'-').'" \>'; }

  my $rs= "";
  $rs.= "<thead> <tr> <th>Student</th>"; foreach (@{$hw}) { $rs.= "<th>".entercell($_)."</th>"; } $rs.= "<th>".entercell("")."</th> </tr> </thead>\n<tbody>";

  foreach my $s (@{$user}) {
    $rs.= "<tr> <th> $s </th> \n";
    foreach my $h (@{$hw}) {
      $rs.= "<td>".entercell($grades->{$s}->{$h})."</td>";
    }
    $rs.= "<td>".entercell("")."</td></tr>\n";
  }
  $rs .= "</tbody>\n";
  %>

  <table class="table" id="gradebrowser">
     <%== $rs %>
  </table>

    <div class="form-group">
      <div class="btn btn-lg"> <button type="submit" class="btn btn-lg" value="submit">Update all Grades</button> </div>
    </div>

  </form>

</main>

